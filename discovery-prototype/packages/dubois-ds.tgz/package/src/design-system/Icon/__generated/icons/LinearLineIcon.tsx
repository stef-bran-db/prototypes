import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgLinearLineIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M14.5 2a1.5 1.5 0 0 1 .09 2.995L12.25 9.673a1.5 1.5 0 1 1-2.729.572L5.517 6.906q-.203.075-.427.09L2.75 11.672a1.5 1.5 0 1 1-1.342-.669l2.34-4.678a1.5 1.5 0 1 1 2.729-.572l4.004 3.339q.202-.075.426-.09l2.34-4.677A1.5 1.5 0 0 1 14.5 2"
      />
    </svg>
  );
}
const LinearLineIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgLinearLineIcon} />;
  }
);
LinearLineIcon.displayName = "LinearLineIcon";
export default LinearLineIcon;
