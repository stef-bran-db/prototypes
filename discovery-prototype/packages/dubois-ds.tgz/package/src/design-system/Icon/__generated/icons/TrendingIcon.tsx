import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgTrendingIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        stroke="currentColor"
        d="M7.04 2.092c.052 0 .105.013.15.039l.015.008.016.007c1.947.905 3.417 2.354 4.31 3.938.66 1.168.997 2.396.995 3.523l-.005.224c-.05 1.132-.453 2.149-1.205 2.882-.75.73-1.85 1.183-3.304 1.186h-.015l-.015.001a4.25 4.25 0 0 1-4.507-4.069A3.51 3.51 0 0 1 5.24 6.697c.246.545.586 1.04 1.003 1.466l.403.412.35-.458c.536-.7.765-1.579.758-2.499-.008-1.094-.35-2.248-.913-3.225l-.005-.007a.196.196 0 0 1 .045-.252.3.3 0 0 1 .158-.042Z"
      />
    </svg>
  );
}
const TrendingIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgTrendingIcon} />;
  }
);
TrendingIcon.displayName = "TrendingIcon";
export default TrendingIcon;
