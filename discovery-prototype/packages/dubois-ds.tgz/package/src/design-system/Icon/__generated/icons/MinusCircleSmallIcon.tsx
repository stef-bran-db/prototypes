import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgMinusCircleSmallIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path fill="currentColor" d="M10.75 7v1.5h-6V7z" />
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M7.75 1a6.75 6.75 0 1 1 0 13.5 6.75 6.75 0 0 1 0-13.5m0 1.5a5.25 5.25 0 1 0 0 10.5 5.25 5.25 0 0 0 0-10.5"
        clipRule="evenodd"
      />
    </svg>
  );
}
const MinusCircleSmallIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgMinusCircleSmallIcon} />
    );
  }
);
MinusCircleSmallIcon.displayName = "MinusCircleSmallIcon";
export default MinusCircleSmallIcon;
