import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgFaceFrownIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <g fill="currentColor" clipPath="url(#FaceFrownIcon_svg__a)">
        <path d="M6 5.25a.75.75 0 0 0 0 1.5h.007a.75.75 0 0 0 0-1.5zM9.25 6a.75.75 0 0 1 .75-.75h.007a.75.75 0 0 1 0 1.5H10A.75.75 0 0 1 9.25 6M10.07 11.12a.75.75 0 0 0 1.197-.903l-.001-.001v-.001l-.003-.003-.005-.006-.015-.02a3 3 0 0 0-.217-.246 4.7 4.7 0 0 0-.626-.546C9.858 9 9.04 8.584 8 8.584s-1.858.416-2.4.81a4.7 4.7 0 0 0-.795.733l-.048.06-.015.019-.005.006-.002.003-.031.044.03-.042a.75.75 0 1 0 1.22.875q.032-.039.103-.115c.096-.1.24-.235.426-.37.375-.273.89-.523 1.517-.523s1.142.25 1.517.523a3.2 3.2 0 0 1 .529.485l.021.025z" />
        <path
          fillRule="evenodd"
          d="M8 .583a7.417 7.417 0 1 0 0 14.834A7.417 7.417 0 0 0 8 .583M2.083 8a5.917 5.917 0 1 1 11.834 0A5.917 5.917 0 0 1 2.083 8"
          clipRule="evenodd"
        />
      </g>
      <defs>
        <clipPath>
          <path fill="#fff" d="M0 0h16v16H0z" />
        </clipPath>
      </defs>
    </svg>
  );
}
const FaceFrownIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgFaceFrownIcon} />;
  }
);
FaceFrownIcon.displayName = "FaceFrownIcon";
export default FaceFrownIcon;
