import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgH4Icon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M2.5 7.25H6V3h1.5v10H6V8.75H2.5V13H1V3h1.5zM13.249 3a.75.75 0 0 1 .75.75L14 9.5h1V11h-1v2h-1.5v-2H9.25a.75.75 0 0 1-.75-.75V9.5a.75.75 0 0 1 .097-.37l3.25-5.75.055-.083A.75.75 0 0 1 12.5 3zm-3.137 6.5H12.5l-.001-4.224z"
      />
    </svg>
  );
}
const H4Icon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgH4Icon} />;
  }
);
H4Icon.displayName = "H4Icon";
export default H4Icon;
