import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgPencilFillIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M11.013 1.513a1.75 1.75 0 0 1 2.474 0l1.086 1.085a1.75 1.75 0 0 1 0 2.475l-1.512 1.513L9.5 3.026zM8.439 4.086l-7.22 7.22a.75.75 0 0 0-.219.53v2.5c0 .414.336.75.75.75h2.5a.75.75 0 0 0 .53-.22L12 7.646z"
      />
    </svg>
  );
}
const PencilFillIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgPencilFillIcon} />;
  }
);
PencilFillIcon.displayName = "PencilFillIcon";
export default PencilFillIcon;
