import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgDomainCirclesThree(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M11.75 13.375a2.625 2.625 0 1 0 0-5.25 2.625 2.625 0 0 0 0 5.25m0-1.25a1.375 1.375 0 1 0 0-2.75 1.375 1.375 0 0 0 0 2.75M4.25 13.375a2.625 2.625 0 1 0 0-5.25 2.625 2.625 0 0 0 0 5.25m0-1.25a1.375 1.375 0 1 0 0-2.75 1.375 1.375 0 0 0 0 2.75M8 7.375a2.625 2.625 0 1 0 0-5.25 2.625 2.625 0 0 0 0 5.25m0-1.25a1.375 1.375 0 1 0 0-2.75 1.375 1.375 0 0 0 0 2.75"
        clipRule="evenodd"
      />
    </svg>
  );
}
const DomainCirclesThree = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgDomainCirclesThree} />
    );
  }
);
DomainCirclesThree.displayName = "DomainCirclesThree";
export default DomainCirclesThree;
