import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgAlignVerticalBottomIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M15 13.5V15H1v-1.5zM8.75 1v8.19l1.72-1.72 1.06 1.06L8 12.06 4.47 8.53l1.06-1.06 1.72 1.72V1z"
      />
    </svg>
  );
}
const AlignVerticalBottomIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon
        ref={forwardedRef}
        {...props}
        component={SvgAlignVerticalBottomIcon}
      />
    );
  }
);
AlignVerticalBottomIcon.displayName = "AlignVerticalBottomIcon";
export default AlignVerticalBottomIcon;
