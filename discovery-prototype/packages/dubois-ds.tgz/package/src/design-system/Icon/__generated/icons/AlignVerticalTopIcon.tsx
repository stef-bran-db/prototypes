import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgAlignVerticalTopIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="m4.47 7.47 1.06 1.06 1.72-1.72V15h1.5V6.81l1.72 1.72 1.06-1.06L8 3.94zM1 1v1.5h14V1z"
      />
    </svg>
  );
}
const AlignVerticalTopIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgAlignVerticalTopIcon} />
    );
  }
);
AlignVerticalTopIcon.displayName = "AlignVerticalTopIcon";
export default AlignVerticalTopIcon;
