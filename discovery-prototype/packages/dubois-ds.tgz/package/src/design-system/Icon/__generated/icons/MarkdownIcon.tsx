import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgMarkdownIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 17 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="m13.75 10.125 1.207-1.268 1.086 1.035L13 13.088 9.957 9.892l1.086-1.035 1.207 1.268V6h1.5zM7.743 3.297A.752.752 0 0 1 9.05 3.8V13h-1.5V5.746L5.056 8.503a.75.75 0 0 1-1.118-.008L1.55 5.785V13H.05V3.8a.75.75 0 0 1 1.312-.496l3.145 3.569z"
      />
    </svg>
  );
}
const MarkdownIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgMarkdownIcon} />;
  }
);
MarkdownIcon.displayName = "MarkdownIcon";
export default MarkdownIcon;
