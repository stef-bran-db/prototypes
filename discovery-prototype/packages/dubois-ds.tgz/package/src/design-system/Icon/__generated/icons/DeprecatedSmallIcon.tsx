import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgDeprecatedSmallIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M8 3a5 5 0 1 1 0 10A5 5 0 0 1 8 3m-3.268 7.585q.301.379.68.68l5.856-5.85a4.2 4.2 0 0 0-.682-.683z"
      />
    </svg>
  );
}
const DeprecatedSmallIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgDeprecatedSmallIcon} />
    );
  }
);
DeprecatedSmallIcon.displayName = "DeprecatedSmallIcon";
export default DeprecatedSmallIcon;
