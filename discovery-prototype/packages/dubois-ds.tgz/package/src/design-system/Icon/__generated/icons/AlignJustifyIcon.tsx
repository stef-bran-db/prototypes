import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgAlignJustifyIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M1 2.5h14V1H1zm14 3.25H1v-1.5h14zm-14 3v-1.5h14v1.5zM1 15v-1.5h14V15zm0-3.25h14v-1.5H1z"
      />
    </svg>
  );
}
const AlignJustifyIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgAlignJustifyIcon} />
    );
  }
);
AlignJustifyIcon.displayName = "AlignJustifyIcon";
export default AlignJustifyIcon;
