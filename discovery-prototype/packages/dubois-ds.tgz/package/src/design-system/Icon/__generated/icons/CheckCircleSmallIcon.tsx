import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgCheckCircleSmallIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M8 3.5c.873 0 1.687.25 2.377.68L9.271 5.285a3 3 0 1 0 1.523 1.629l-2.787 2.79-1.882-1.882.79-.789 1.092 1.093 3.24-3.238A4.5 4.5 0 1 1 8 3.5"
      />
    </svg>
  );
}
const CheckCircleSmallIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgCheckCircleSmallIcon} />
    );
  }
);
CheckCircleSmallIcon.displayName = "CheckCircleSmallIcon";
export default CheckCircleSmallIcon;
