import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgDeprecatedIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M8 2a6 6 0 1 1 0 12A6 6 0 0 1 8 2m-3.92 9.103q.36.454.815.816l7.026-7.023a5 5 0 0 0-.817-.817z"
      />
    </svg>
  );
}
const DeprecatedIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgDeprecatedIcon} />;
  }
);
DeprecatedIcon.displayName = "DeprecatedIcon";
export default DeprecatedIcon;
