import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgTrendingFillIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M6.622 1.707a.81.81 0 0 1 .81-.014c2.044.95 3.592 2.472 4.535 4.145.741 1.314 1.11 2.72 1.053 4.015-.054 1.237-.497 2.382-1.355 3.218S9.574 14.396 8.013 14.4a4.75 4.75 0 0 1-5.037-4.547v-.007a4.01 4.01 0 0 1 2.06-3.608.46.46 0 0 1 .642.216c.223.506.535.967.921 1.36.453-.59.661-1.353.655-2.191-.007-.999-.321-2.068-.846-2.979a.695.695 0 0 1 .214-.936"
        clipRule="evenodd"
      />
    </svg>
  );
}
const TrendingFillIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgTrendingFillIcon} />
    );
  }
);
TrendingFillIcon.displayName = "TrendingFillIcon";
export default TrendingFillIcon;
