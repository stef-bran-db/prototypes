import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgTokenIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 12 12"
      {...props}
    >
      <mask id="TokenIcon_svg__a" fill="#fff">
        <path d="M5.596 10.799a5 5 0 1 0 .082-9.621l.258.94a4.025 4.025 0 1 1-.066 7.745z" />
      </mask>
      <path
        stroke="currentColor"
        strokeWidth={2}
        d="M5.596 10.799a5 5 0 1 0 .082-9.621l.258.94a4.025 4.025 0 1 1-.066 7.745z"
        mask="url(#TokenIcon_svg__a)"
      />
      <circle cx={5} cy={6} r={4.5} stroke="currentColor" />
      <circle cx={5} cy={6} r={1.5} stroke="currentColor" />
    </svg>
  );
}
const TokenIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgTokenIcon} />;
  }
);
TokenIcon.displayName = "TokenIcon";
export default TokenIcon;
