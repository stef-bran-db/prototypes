import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgStepAfterLineIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M1.5 14a1.5 1.5 0 1 1 1.298-2.25H5V6.299A1.499 1.499 0 1 1 7.048 4.25H9.75a.75.75 0 0 1 .75.75v3.202c.227.132.416.32.548.548H13.5V5.049a1.5 1.5 0 1 1 1.5 0V9.5a.75.75 0 0 1-.75.75h-3.202A1.498 1.498 0 1 1 9 8.202V5.75H7.048c-.132.227-.32.417-.548.549V12.5a.75.75 0 0 1-.75.75H2.798c-.26.448-.743.75-1.298.75"
      />
    </svg>
  );
}
const StepAfterLineIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgStepAfterLineIcon} />
    );
  }
);
StepAfterLineIcon.displayName = "StepAfterLineIcon";
export default StepAfterLineIcon;
