import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgPivotOperatorIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="m15.84 9.03-1.06 1.06-.72-.719v1.94a2.75 2.75 0 0 1-2.75 2.75H9.372l.72.72-1.06 1.06L6.5 13.31l2.53-2.53 1.06 1.06-.719.72h1.94c.69 0 1.25-.56 1.25-1.25V9.37l-.72.72-1.06-1.06L13.31 6.5z"
      />
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M14.25 1a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-.75.75H5.5v8.75a.75.75 0 0 1-.75.75h-3a.75.75 0 0 1-.75-.75v-9.5A.75.75 0 0 1 1.75 4H4V1.75A.75.75 0 0 1 4.75 1zM2.5 13.5H4v-8H2.5zm3-9.5h8V2.5h-8z"
        clipRule="evenodd"
      />
    </svg>
  );
}
const PivotOperatorIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgPivotOperatorIcon} />
    );
  }
);
PivotOperatorIcon.displayName = "PivotOperatorIcon";
export default PivotOperatorIcon;
