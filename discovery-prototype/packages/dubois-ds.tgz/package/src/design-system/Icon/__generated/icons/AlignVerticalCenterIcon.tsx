import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgAlignVerticalCenterIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="m11.53 12.97-1.06 1.06-1.72-1.72V16h-1.5v-3.69l-1.72 1.72-1.06-1.06L8 9.44zM15 8.75H1v-1.5h14zM8.75 3.69l1.72-1.72 1.06 1.06L8 6.56 4.47 3.03l1.06-1.06 1.72 1.72V0h1.5z"
      />
    </svg>
  );
}
const AlignVerticalCenterIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon
        ref={forwardedRef}
        {...props}
        component={SvgAlignVerticalCenterIcon}
      />
    );
  }
);
AlignVerticalCenterIcon.displayName = "AlignVerticalCenterIcon";
export default AlignVerticalCenterIcon;
