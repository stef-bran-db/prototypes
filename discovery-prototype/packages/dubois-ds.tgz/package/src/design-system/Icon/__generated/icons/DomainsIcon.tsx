import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgDomainsIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M6.25 3.25a1.75 1.75 0 1 1 3.5 0 1.75 1.75 0 0 1-3.5 0m-1.5 0a3.25 3.25 0 1 0 6.5 0 3.25 3.25 0 0 0-6.5 0M11 11.75a1.75 1.75 0 1 1 3.5 0 1.75 1.75 0 0 1-3.5 0m-1.5 0a3.25 3.25 0 1 0 6.5 0 3.25 3.25 0 0 0-6.5 0M1.5 11.75a1.75 1.75 0 1 1 3.5 0 1.75 1.75 0 0 1-3.5 0m-1.5 0a3.25 3.25 0 1 0 6.5 0 3.25 3.25 0 0 0-6.5 0"
      />
    </svg>
  );
}
const DomainsIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgDomainsIcon} />;
  }
);
DomainsIcon.displayName = "DomainsIcon";
export default DomainsIcon;
