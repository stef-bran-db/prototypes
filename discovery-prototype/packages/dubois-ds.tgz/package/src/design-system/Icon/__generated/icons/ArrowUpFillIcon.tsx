import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgArrowUpFillIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M8 .25c.199 0 .39.08.53.22l6.25 6.25A.75.75 0 0 1 14.25 8H10.5v7.25a.75.75 0 0 1-.75.75h-3.5a.75.75 0 0 1-.75-.75V8H1.75a.751.751 0 0 1-.53-1.28L7.47.47l.114-.094A.75.75 0 0 1 8 .25"
      />
    </svg>
  );
}
const ArrowUpFillIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return (
      <Icon ref={forwardedRef} {...props} component={SvgArrowUpFillIcon} />
    );
  }
);
ArrowUpFillIcon.displayName = "ArrowUpFillIcon";
export default ArrowUpFillIcon;
