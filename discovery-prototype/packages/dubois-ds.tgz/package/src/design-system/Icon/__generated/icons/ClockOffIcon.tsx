import type { Ref } from "react";
/* eslint-disable no-restricted-imports, react-component-name/react-component-name */
import * as React from "react";
import { forwardRef } from "react";

import type { IconProps } from "../../Icon";
import { Icon } from "../../Icon";

function SvgClockOffIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      fill="none"
      viewBox="0 0 16 16"
      {...props}
    >
      <path
        fill="currentColor"
        d="M8 0a8 8 0 0 1 7.944 8.929 5.005 5.005 0 0 0-1.454-1.265A6.5 6.5 0 0 0 1.5 8a6.5 6.5 0 0 0 6.164 6.49 5 5 0 0 0 1.265 1.454A8 8 0 1 1 8 0"
      />
      <path
        fill="currentColor"
        d="M8.75 8a.75.75 0 0 1-.22.53l-2 2-1.06-1.06 1.78-1.78V3h1.5z"
      />
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8m0 2.94-1.125-1.126-1.06 1.061L10.94 12l-1.126 1.125 1.061 1.06L12 13.06l1.125 1.125 1.06-1.06L13.06 12l1.125-1.125-1.06-1.06z"
        clipRule="evenodd"
      />
    </svg>
  );
}
const ClockOffIcon = forwardRef(
  (props: IconProps, forwardedRef?: Ref<HTMLSpanElement>) => {
    return <Icon ref={forwardedRef} {...props} component={SvgClockOffIcon} />;
  }
);
ClockOffIcon.displayName = "ClockOffIcon";
export default ClockOffIcon;
