import { expect, describe, it, jest, beforeEach } from '@jest/globals';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { Modal } from './Modal';
import { setupDesignSystemEventProviderForTesting } from '../DesignSystemEventProvider';
import { setupSafexTesting } from '../utils/safex-test-utils';

describe('Modal', () => {
  const { setSafex } = setupSafexTesting();

  describe('Radix Modal afterClose', () => {
    beforeEach(() => {
      setSafex({
        'databricks.fe.designsystem.useRadixModal': true,
      });
    });

    it('calls afterClose when modal is closed', async () => {
      const afterClose = jest.fn();
      const { rerender } = render(
        <Modal componentId="afterClose-test" visible title="Test modal" afterClose={afterClose} />,
      );

      expect(afterClose).not.toHaveBeenCalled();

      rerender(<Modal componentId="afterClose-test" visible={false} title="Test modal" afterClose={afterClose} />);

      expect(afterClose).toHaveBeenCalledTimes(1);
    });

    it('does not call afterClose when modal is opened', async () => {
      const afterClose = jest.fn();
      const { rerender } = render(
        <Modal componentId="afterClose-test" visible={false} title="Test modal" afterClose={afterClose} />,
      );

      expect(afterClose).not.toHaveBeenCalled();

      rerender(<Modal componentId="afterClose-test" visible title="Test modal" afterClose={afterClose} />);

      expect(afterClose).not.toHaveBeenCalled();
    });

    it('does not call afterClose when afterClose prop is not provided', async () => {
      const { rerender } = render(<Modal componentId="afterClose-test" visible title="Test modal" />);

      rerender(<Modal componentId="afterClose-test" visible={false} title="Test modal" />);

      expect(screen.queryByText('Test modal')).not.toBeInTheDocument();
    });
  });

  describe('enabled defaultButtonComponentView', () => {
    it("doesn't render with ant-scrolling-effect class on body", async () => {
      const { baseElement } = render(
        <Modal
          componentId="codegen_design-system_src_design-system_modal_modal.test.tsx_11"
          visible
          title="Test modal"
        />,
      );
      expect(baseElement).not.toHaveClass('ant-scrolling-effect');
      expect(baseElement).toHaveClass('scroll-lock-effect');
    });
    it('handles views & clicks with DesignSystemEventProvider', async () => {
      // Disable IntersectionObserver for useNotifyOnFirstView hook to trigger
      (window as any).IntersectionObserver = undefined;

      // Arrange
      const handleOk = jest.fn();
      const handleCancel = jest.fn();
      const eventCallback = jest.fn();
      const { DesignSystemEventProviderForTest } = setupDesignSystemEventProviderForTesting(eventCallback);
      render(
        <DesignSystemEventProviderForTest>
          <Modal
            componentId="bestModalEver"
            visible
            title="Test modal"
            cancelText="Cancel"
            onCancel={handleCancel}
            okText="Ok"
            onOk={handleOk}
            shouldStartInteraction
          />
        </DesignSystemEventProviderForTest>,
      );
      expect(handleCancel).not.toHaveBeenCalled();
      expect(handleOk).not.toHaveBeenCalled();

      // Assert for view
      expect(screen.getByText('Test modal')).toBeVisible();
      expect(eventCallback).toHaveBeenCalledTimes(3);
      expect(eventCallback).toHaveBeenCalledWith({
        eventType: 'onView',
        componentId: 'bestModalEver.footer.cancel',
        componentType: 'button',
        shouldStartInteraction: false,
        value: undefined,
      });
      expect(eventCallback).toHaveBeenCalledWith({
        eventType: 'onView',
        componentId: 'bestModalEver.footer.ok',
        componentType: 'button',
        shouldStartInteraction: false,
        value: undefined,
      });
      expect(eventCallback).toHaveBeenCalledWith({
        eventType: 'onView',
        componentId: 'bestModalEver',
        componentType: 'modal',
        componentSubType: undefined,
        shouldStartInteraction: false,
        value: undefined,
      });

      // Assert for cancel
      await userEvent.click(screen.getByText('Cancel'));
      expect(handleCancel).toHaveBeenCalledTimes(1);
      expect(eventCallback).toHaveBeenCalledTimes(4);
      expect(eventCallback).toHaveBeenNthCalledWith(4, {
        eventType: 'onClick',
        componentId: 'bestModalEver.footer.cancel',
        componentType: 'button',
        shouldStartInteraction: true,
        isInteractionSubject: true,
        value: undefined,
        event: expect.anything(),
      });

      // Assert for close ( This isn't a du bois button yet, so it's not being tracked )
      await userEvent.click(screen.getByText('Ok'));
      expect(handleOk).toHaveBeenCalledTimes(1);
      expect(eventCallback).toHaveBeenCalledTimes(5);
      expect(eventCallback).toHaveBeenNthCalledWith(5, {
        eventType: 'onClick',
        componentId: 'bestModalEver.footer.ok',
        componentType: 'button',
        shouldStartInteraction: true,
        isInteractionSubject: true,
        value: undefined,
        event: expect.anything(),
      });
    });

    it('handles views & clicks with DesignSystemEventProvider but with shouldStartInteraction not set', async () => {
      // Disable IntersectionObserver for useNotifyOnFirstView hook to trigger
      (window as any).IntersectionObserver = undefined;

      // Arrange
      const handleOk = jest.fn();
      const handleCancel = jest.fn();
      const eventCallback = jest.fn();
      const { DesignSystemEventProviderForTest } = setupDesignSystemEventProviderForTesting(eventCallback);
      render(
        <DesignSystemEventProviderForTest>
          <Modal
            componentId="bestModalEver"
            visible
            title="Test modal"
            cancelText="Cancel"
            onCancel={handleCancel}
            okText="Ok"
            onOk={handleOk}
          />
        </DesignSystemEventProviderForTest>,
      );
      expect(handleCancel).not.toHaveBeenCalled();
      expect(handleOk).not.toHaveBeenCalled();

      // Assert for view
      expect(screen.getByText('Test modal')).toBeVisible();
      expect(eventCallback).toHaveBeenCalledTimes(3);
      expect(eventCallback).toHaveBeenCalledWith({
        eventType: 'onView',
        componentId: 'bestModalEver.footer.cancel',
        componentType: 'button',
        shouldStartInteraction: false,
        value: undefined,
      });
      expect(eventCallback).toHaveBeenCalledWith({
        eventType: 'onView',
        componentId: 'bestModalEver.footer.ok',
        componentType: 'button',
        shouldStartInteraction: false,
        value: undefined,
      });
      expect(eventCallback).toHaveBeenCalledWith({
        eventType: 'onView',
        componentId: 'bestModalEver',
        componentType: 'modal',
        shouldStartInteraction: false,
        value: undefined,
      });

      // Assert for cancel
      await userEvent.click(screen.getByText('Cancel'));
      expect(handleCancel).toHaveBeenCalledTimes(1);
      expect(eventCallback).toHaveBeenCalledTimes(4);
      expect(eventCallback).toHaveBeenNthCalledWith(4, {
        eventType: 'onClick',
        componentId: 'bestModalEver.footer.cancel',
        componentType: 'button',
        shouldStartInteraction: false,
        isInteractionSubject: true,
        value: undefined,
        event: expect.anything(),
      });

      // Assert for close ( This isn't a du bois button yet, so it's not being tracked )
      await userEvent.click(screen.getByText('Ok'));
      expect(handleOk).toHaveBeenCalledTimes(1);
      expect(eventCallback).toHaveBeenCalledTimes(5);
      expect(eventCallback).toHaveBeenNthCalledWith(5, {
        eventType: 'onClick',
        componentId: 'bestModalEver.footer.ok',
        componentType: 'button',
        shouldStartInteraction: false,
        isInteractionSubject: true,
        value: undefined,
        event: expect.anything(),
      });
    });
  });
});
