import { getBaseConfig } from '@databricks/config-jest/config';

const config = getBaseConfig({
  compiler: 'swc',
  enableEmotion: true,
});

process.env.TZ = 'UTC';

export default config;
